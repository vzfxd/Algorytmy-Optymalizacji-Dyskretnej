#include <iostream>
#include <vector>
#include <queue>
#include <limits>
#include <random>
#include <bits/stdc++.h>

using namespace std;

typedef pair<int,int> flow_path;

// Struktura reprezentująca krawędź w grafie
struct Edge {
    int target;
    int capacity;
    int flow;
};

// Klasa reprezentująca graf skierowany
class Graph {
    int V;  // Liczba wierzchołków
    vector<vector<Edge>> adj;  // Lista sąsiedztwa

public:
    Graph(int V) : V(V), adj(V) {}

    // Dodaj krawędź do grafu
    void addEdge(int u, int v, int capacity)
    {
        Edge uv = {v, capacity, 0};
        adj[u].push_back(uv);
    }

    // BFS dla znalezienia ścieżki powiększającej
    bool bfs(vector<int>& parent) {
        vector<bool> visited(V, false);
        queue<int> q;

        q.push(0);
        visited[0] = true;
        parent[0] = -1;

        while (!q.empty()) {
            int u = q.front();
            q.pop();

            for (const auto& edge : adj[u]) {
                int v = edge.target;
                int residualCapacity = edge.capacity - edge.flow;

                if (!visited[v] && residualCapacity > 0) {
                    q.push(v);
                    parent[v] = u;
                    visited[v] = true;
                }
            }
        }

        return visited[V - 1];  // Czy ujście zostało odwiedzone
    }

    // Algorytm Edmondsa-Karpa
    flow_path edmondsKarp(bool printFlow) {
        int maxFlow = 0;
        int numPaths = 0;
        vector<int> parent(V);

        while (bfs(parent))
        {
            int pathFlow = numeric_limits<int>::max();

            //minimalna przepustowość na ścieżce powiększającej
            for (int v = V - 1; v != 0; v = parent[v])
            {
                int u = parent[v];
                for (const auto& edge : adj[u])
                {
                    if (edge.target == v)
                    {
                        pathFlow = min(pathFlow, edge.capacity - edge.flow);
                        break;
                    }
                }
            }

            //Aktualizacja przepływów
            for (int v = V - 1; v != 0; v = parent[v])
            {
                int u = parent[v];
                for (auto& edge : adj[u])
                {
                    if (edge.target == v)
                    {
                        edge.flow += pathFlow;
                        break;
                    }
                }
                for (auto& edge: adj[v])
                {
                    if(edge.target == u)
                    {
                        edge.flow -= pathFlow;
                        break;
                    }
                }
            }

            maxFlow += pathFlow;
            numPaths++;

            if (printFlow)
            {
                for (int v = V - 1; v != 0; v = parent[v])
                {
                    int u = parent[v];
                    for (const auto& edge : adj[u])
                    {
                        if (edge.target == v)
                        {
                            cout << u << " -> " << v << ": " << edge.flow << "/" << edge.capacity << endl;
                            break;
                        }
                    }
                    v = u;
                }
                cout << endl;
            }

        }

        return make_pair(maxFlow,numPaths);
    }
};

int main(int argc, char* argv[]) {
    bool printFlow = false;
    int k = stoi(argv[2]);
    if (argc>3 && string(argv[3]) == "--printFlow")
        printFlow = true;

    int V = 1 << k;

    Graph graph(V);
    random_device rd;
    mt19937 gen(rd());

    for (int i = 0; i < V; i++)
    {
        for (int j = 0; j < k; j++)
        {
            int neighbour = i ^ (1 << j);
            if (neighbour > i)
            {
                int i1 = __builtin_popcount(i);
                int n1 =  __builtin_popcount(neighbour);
                int i0 = k - i1;
                int n0 = k - n1;
                int capacity = max(max(i1,n1),max(i0,n0));

                int bound = 1 << capacity;

                uniform_int_distribution<int> dist(1, bound);

                graph.addEdge(i, neighbour, dist(gen));
            }
        }
    }
    clock_t start = clock();
    flow_path result = graph.edmondsKarp(printFlow);
    clock_t end = clock();

    cout << "Maksymalny przepływ: " << result.first << endl;
    cout << "Liczba ściezek: " << result.second << endl;
    cout << "Czas działania: " << double(end - start) / CLOCKS_PER_SEC << endl;

    return 0;
}