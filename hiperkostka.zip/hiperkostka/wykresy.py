from matplotlib import pyplot as plt
import subprocess


def zad2(k):
    reps = 1000
    x_axis = [_ for _ in range(1,k+1)]
    y_axis = []

    for i in range(1,k+1):
        result = 0
        for _ in range(reps):
            result += int(subprocess.run(["./zad2","--size",str(k),"--degree",str(i)],capture_output=True,text=True).stdout.split(" ")[0])
        y_axis.append(result/reps)
    
    plt.scatter(x_axis,y_axis)
    plt.title(f"k={k}")
    plt.savefig(f"zad2_{k}.png")
    plt.close()

def zad2_2(i):
    reps = 1000
    x_axis = [_ for _ in range(i,11)]
    y_axis = []

    for k in range(i,11):
        result = 0
        for _ in range(reps):
            result += float(subprocess.run(["./zad2","--size",str(k),"--degree",str(i)],capture_output=True,text=True).stdout.split(" ")[1])
        y_axis.append(result/reps)

    plt.scatter(x_axis,y_axis)
    plt.title(f"i={i}")
    plt.savefig(f"zad2_i_{i}.png")
    plt.close()

def zad1():
    reps = 20
    x_axis = [_ for _ in range(1,17)]
    flow_axis = []
    time_axis = []
    path_axis = []

    for k in x_axis:
        flow = 0
        time = 0
        path = 0
        for _ in range(reps):
            result = subprocess.run(["./zad1","--size",str(k)],capture_output=True,text=True).stdout
            flow += int(result.split("\n")[0].split(": ")[1])
            path += int(result.split("\n")[1].split(": ")[1])
            time += float(result.split("\n")[2].split(": ")[1])
        print(f"{k} done\n")
        flow_axis.append(flow/reps)
        time_axis.append(time/reps)
        path_axis.append(path/reps)

    plt.scatter(x_axis,flow_axis)
    plt.title("sredni maksymalny przeplyw")
    plt.show()

    plt.scatter(x_axis,time_axis)
    plt.title("sredni czas")
    plt.show()

    plt.scatter(x_axis,path_axis)
    plt.title("srednia liczba sciezek")
    plt.show()


for k in range(3,11):
    zad2(k)

# for i in range(1,9):
#     zad2_2(i)