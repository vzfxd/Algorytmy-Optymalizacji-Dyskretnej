#include <iostream>
#include <vector>
#include <random>
#include <algorithm>

typedef std::vector<std::vector<int>> Graph;

bool dfs(const Graph& g, int u, std::vector<int>& mate, std::vector<bool>& visited)
{
   visited[u] = true;
   for (int v : g[u])
   {
       if (!visited[v])
       {
           visited[v] = true;
           if (mate[v] == -1 || dfs(g, mate[v], mate, visited))
           {
               mate[u] = v;
               mate[v] = u;
               return true;
           }
       }
   }
   return false;
}

int calculateMaxMatching(const Graph& g, std::vector<int>& mate)
{
   int vertexCount = g.size();
   int matchingSize = 0;

   for (int u = 0; u < vertexCount; ++u)
   {
       if (mate[u] == -1)
       {
           std::vector<bool> visited(vertexCount, false);
           if (dfs(g, u, mate, visited))
               matchingSize++;
       }
   }
   return matchingSize;
}

Graph generateRandomGraph(int k, int i)
{
    int vertexCount = 1 << k;
    Graph g(vertexCount * 2);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(0, vertexCount - 1);

    std::vector<int> V1(vertexCount);
    std::vector<int> V2(vertexCount);
    for (int j = 0; j < vertexCount; j++)
    {
        V1[j] = j;
        V2[j] = j + vertexCount;
    }

    for (int u : V1)
    {
        for (int j = 0; j < i; j++)
        {
            int v = V2[dist(gen)];
            while (std::find(g[u].begin(), g[u].end(), v) != g[u].end())
                v = V2[dist(gen)];

            g[u].push_back(v);
        }
    }

    for (int u : V2)
    {
        for (int j = 0; j < i; j++)
        {
            int v = V1[dist(gen)];
            while (std::find(g[u].begin(), g[u].end(), v) != g[u].end())
                v = V1[dist(gen)];

            g[u].push_back(v);
        }
    }

    return g;
}

void printMatching(const Graph& g, const std::vector<int>& mate)
{
    int vertexCount = g.size();

    std::cout << "Matching Edges:" << std::endl;
    for (int u = 0; u < vertexCount; ++u)
    {
        if (mate[u] != -1 && u < mate[u])
        {
            std::cout << u << " -- " << mate[u] << std::endl;
        }
    }
}

int main(int argc, char* argv[])
{
    if (argc < 3)
    {
        std::cout << "Usage: program_name --size k --degree i [--printMatching]" << std::endl;
        return 0;
    }

    int k = std::stoi(argv[2]);
    int i = std::stoi(argv[4]);
    bool _printMatching = false;

    if (argc > 5 && std::string(argv[5]) == "--printMatching")
        _printMatching = true;

    Graph g = generateRandomGraph(k, i);
    std::vector<int> mate(g.size(), -1);

    clock_t start = clock();
    int maxMatchingSize = calculateMaxMatching(g, mate);
    clock_t end = clock();

    std::cout << maxMatchingSize << " " << double(end - start) / CLOCKS_PER_SEC << std::endl;

    if (_printMatching)
        printMatching(g, mate);


    return 0;
}